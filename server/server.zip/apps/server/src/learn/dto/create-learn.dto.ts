export class CreateLearnDto {}
