export class CreateTrackerDto {}
