export class CreateCourseDto {}
